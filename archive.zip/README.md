# AccTez-Main
open-source framework for issuing tickets on the Tezos blockchain as tokens



# Stripe Setup

## Requirements
Stripe Account
- Publishable Key
- Secret Key

## Setup
update environment variables reference .env.example

note:
assumes USD currency


## Run Local Server
```
npm run build
node server.js 
```

## Go to site
http://localhost:3000



